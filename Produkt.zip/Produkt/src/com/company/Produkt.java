package com.company;



    public class Produkt
    {


        private String nazwa;
        private double cena;
        private int ilość;
        public Produkt(String name, double price, int value){
            this.nazwa = name;
            this.cena = price;
            this.ilość = value;
        }
        public String toString(){
            System.out.println("Nazwa:     "+ nazwa);
            System.out.println("Cena:     "+ cena);
            System.out.println("Ilość:     "+ ilość);
            return "chleb";
        }

    }

