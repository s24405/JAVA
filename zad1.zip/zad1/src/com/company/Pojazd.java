package com.company;


public class Pojazd {
    static int liczba_kol;
    static String kolor;
    static String dzwiek;

    public String informacje(){
        return liczba_kol + " " + kolor + " " + dzwiek + " ";
    }


}