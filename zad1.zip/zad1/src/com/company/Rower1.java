package com.company;

public class Rower1 {
    public class Rower extends Pojazd{
        String rodzaj;

        @Override
        public String informacje() {


            return liczba_kol + " " + kolor + " " + dzwiek + " " + Samochód.silnik + rodzaj;
        }
    }
}
