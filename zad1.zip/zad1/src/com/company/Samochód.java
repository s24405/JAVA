package com.company;


    public class Samochód extends Pojazd {
        static String silnik;

        @Override
        public String informacje() {


            return liczba_kol + " " + kolor + " " + dzwiek + " " + silnik;
        }

    }

