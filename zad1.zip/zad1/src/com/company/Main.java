package com.company;

public class Main {

    public static void main(String[] args) {

        class Zadanie1 {
            Pojazd pojazd1 = new Pojazd();
            Pojazd pojazd2 = new Pojazd();
            Pojazd pojazd3 = new Pojazd();
            Pojazd pojazd4 = new Pojazd();
            Pojazd pojazd5 = new Pojazd();
            Pojazd pojazd6 = new Pojazd();
        }
    }
}