package com.company;



import static java.lang.Math.sqrt;

    public class Równoboczny extends Trójkąt

    {
        public Równoboczny(float bok)

        {

            h = 0;
            a = bok;

        }
        @Override
        public float ObliczPole()

        {
            float pole = (float) (a*a*sqrt(3));
            return pole/4;
        }


    }



