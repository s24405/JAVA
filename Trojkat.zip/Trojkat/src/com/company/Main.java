package com.company;

public class Main {



        public static void main(String[] args) {
            Trójkąt trojkat1 = new Trójkąt(1);
            System.out.println(trojkat1.ObliczPole());

            Równoboczny trojkat2 = new Równoboczny(13);
            System.out.println(trojkat2.ObliczPole());
        }
    }
