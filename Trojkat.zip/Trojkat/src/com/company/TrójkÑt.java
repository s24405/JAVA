package com.company;

public class Trójkąt {

        static float a;
        static float h;

        public Trójkąt()

        {
            a = 1;
            h = 2;
        }
        public Trójkąt(float wysokosc)
        {
            this();
            h = wysokosc;
        }
        public float ObliczPole()

        {
            float pole = a*h/2;
            return pole;
        }

    }

