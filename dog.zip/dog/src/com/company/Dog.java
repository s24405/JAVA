package com.company;

public class Dog {


        public void szczekaj()
        {
            System.out.println("Woof Woof");
        }

}
